from django.shortcuts import render
from .models import User

# Create your views here.
def login(request, *args, **kargs):

    email = request.POST.get('email', False)
    password = request.POST.get('password', False)
    if email == False:
        newName = request.POST.get('newName', False)
        newEmail = request.POST.get('newEmail', False)
        newPassword = request.POST.get('newPassword', False)
        newJob = request.POST.get('job', False)
        if newName != False:
            newUser = User(name=newName, email=newEmail, password=newPassword, identity=newJob)
            newUser.save()
    else:

        try:
            ThisUser = User.objects.get(email=email)
            if ThisUser.password == password:
                print("login sucssful")
            else:
                print("login fail")
                return render(request, "members/login_fail.html", {})
        except User.DoesNotExist:
            return render(request, "members/login_fail.html", {})


    """
    password = request.POST["password"]

    newName = request.POST["newName"]
    newEmail = request.POST["newEmail"]
    newPassword = request.POST["newPassword"]
    job = request.POST["job"]
    """

    #newUser = User(name=newName, email=newEmail, password=newPassword, identity=job)
    #newUser.save()

    context = {}
    return render(request, "members/login.html", context)



def forget(request, *args, **kargs):
    context = {}
    return render(request, "members/forget.html", context)