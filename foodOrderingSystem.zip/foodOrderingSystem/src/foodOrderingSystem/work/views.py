from django.shortcuts import render

# Create your views here.
def mainStaff(request, *args, **kargs):

    context = {}
    return render(request, "staff/staff.html", context)


def order(request, *args, **kargs):

    context = {}
    return render(request, "staff/order.html", context)



def checkBill(request, *args, **kargs):

    context = {}
    return render(request, "staff/checkBill.html", context)


def bill(request, *args, **kargs):

    context = {}
    return render(request, "staff/bill.html", context)