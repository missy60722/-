from django.db import models

# Create your models here.
class mealsOrdered(models.Model):
    mealName        = models.CharField(max_length=10)
    price           = models.IntegerField()
    table           = models.IntegerField()

class mealsBePaid(models.Model):
    mealName        = models.CharField(max_length=10)
    price           = models.IntegerField()
    table           = models.IntegerField()


